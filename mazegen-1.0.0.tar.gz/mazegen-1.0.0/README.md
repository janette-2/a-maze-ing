*This project has been created as part of the 42 curriculum by cvaz-alf and janrodri*

# Description

Reusable maze generator package for the A-Maze-ing project.

# Basic usage

```python
from mazegen import MazeGenerator

gen = MazeGenerator(width=20, height=15, seed=42, perfect=True)
maze = gen.generate()
path = gen.solve((0, 0), (19, 14))
grid = gen.get_grid()